def eda(number):
    print("EDA MinervaML")