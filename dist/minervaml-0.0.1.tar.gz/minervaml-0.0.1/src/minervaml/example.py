def add_one(number):
    print("MinervaML")
    return number + 1